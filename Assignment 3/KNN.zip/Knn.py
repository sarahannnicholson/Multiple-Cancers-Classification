import csv
import numpy as np
from sklearn.metrics import accuracy_score
from scipy.spatial.distance import euclidean
from collections import Counter
import random



class Dataset(object):
	""" Class responsible for interfacing with our data """

	def __init__(self, datafile):
		self.X = []
		self.Y = []
		self.K = 1
		self.clusterDensity = 1
		with open(datafile, 'r') as data:
			reader = csv.DictReader(data)
			for row in reader:
				self.X.append(map(float, row.values()[1:-1]))
				self.Y.append(row.pop('Species', None))
		self.data()
		self.clusterDistance()

	def data(self):
		#Data for step 1
		filtered = [i for i, x in enumerate(self.Y) if x == 'Iris-setosa']
		random.shuffle(filtered)
		Y =  [self.Y[i] for i in filtered]
		X = [self.X[i] for i in filtered]
		self.trainX = X[:10]
		self.trainY = Y[:10]
		self.validateX = X[-5:]
		self.validateY = Y[-5:]

		#Data for Step 2
		self.testX = X[-10:-5]
		self.testY = Y[-10:-5]

		filtered = [i for i, x in enumerate(self.Y) if x == 'Iris-versicolor']
		random.shuffle(filtered)
		Y =  [self.Y[i] for i in filtered]
		X = [self.X[i] for i in filtered]
		self.testX.extend(X[:5])
		self.testY.extend(Y[:5])

	def clusterDistance(self):
		distance = []
		for i in range(len(self.trainY)):
			for j in range(len(self.trainY)):
				distance.append(euclidean(self.trainX[i], self.trainX[j]))
		self.clusterDensity = np.mean(distance)
		print self.clusterDensity


	def neighbours(self, test):
		distance = []
		for i in range(len(self.trainY)):
			distance.append(euclidean(self.trainX[i], test))

		return np.sort(distance)[:self.K]

	def vote(self, n):
		closest = n[0]
		if closest < self.clusterDensity:
			return "Iris-setosa"
		else:
			return "Not Iris-setosa"

	def validate(self):
		for i in range(len(self.validateY)):
			n = self.neighbours(self.validateX[i])
			print "Actual: ", self.testY[i], "Predicted: ", self.vote(n)

	def predict(self):
		for i in range(len(self.testY)):
			n = self.neighbours(self.testX[i])
			print "Actual: ", self.testY[i], "Predicted: ", self.vote(n)


if __name__ == '__main__':
	train = Dataset('data/Iris.csv')
	
	print '======= Step 1, Validate =========='
	train.validate()

	print '======= Step 2, Production =========='
	train.predict()
















#
